#include "character.h"

//constructor
Character::Character() {}

// destructor
Character::~Character() {}


void Character::used(Player *p) {
    return;
}

void Character::obtained(Player *p) {
    return;
}
