#include "stuff.h"

//static field of stuff, if isfrozen is true, then all the enemy can't move.
bool Stuff::isFrozen = 0;

//constructor
Stuff::Stuff() {}

//destructor
Stuff::~Stuff() {}

//return the image of each stuff
char Stuff::get_image() {
    return image;
}


// frozen all stuffs, so all stuffs can't move, except for player
void Stuff::freeze() {
    isFrozen = !isFrozen;
}

// is valid is true if it's walkable
bool Stuff::is_valid() {
    return isValid;
}
