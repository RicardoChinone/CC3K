#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include "cell.h"
#include "gameplay.h"
using namespace std;

int main(int argc, char* argv[]) {
    srand(time(0));
    ifstream f;                 // readin file if has one
    if( argc == 2) {
        f.open(argv[1]);
    } else {
        f.open("map.txt");
    }
    Gameplay *g = new Gameplay(f);
    string s;
    int count = 0;
    if (count == 0) {             // initializing the game
        cout << "Please choose your race." << endl;
        cout << "Please Enter:" << endl;
        cout << "s: Shade, d: Dwarf, v: Vampire, g: Goblin, t: Troll, i: Pirate" << endl;
        while(cin >> s) {
            if(s == "s") {
                g->changeRace("Shade");
                break;
            } else if(s == "d") {
                g->changeRace("Drow");
                break;
            } else if(s == "v") {
                g->changeRace("Vampire");
                break;
            } else if(s == "g") {
                g->changeRace("Goblin");
                break;
            } else if(s == "t") {
                g->changeRace("Troll");
                break;
            } else if(s == "i") {
                g->changeRace("Pirate");
                break;
            } else {
                cout << "Illegal Race Name. Please enter race again." << endl;
            }
        }
        count++;
        g->print_map();
        cout << "Player character has spawned." << endl;
        cout << "Please enter order" << endl;
        while(cin >> s){                               // start the game
            if(s == "u") {
                cin >> s;
                g->use(s);
            } else if(s == "q"){
                break;
            } else if(s == "a") {
                cin >> s;
                g->attack(s);
            } else if(s == "ea" || s == "no" || s == "so" || s == "we" ||
                        s == "ne" || s == "nw" || s == "se" || s == "sw") {
                g->move(s);
            } else if(s == "f") {
                g->freeze();
            } else if(s == "r") {
                count = 0;
            }
            g->print_map();
        }
        cout << "Game Over" << endl;
        cout << "Exit Game" << endl;
    }
}

        
