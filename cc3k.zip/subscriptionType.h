#ifndef _SUBSCRIPTIONSTYPE_H_
#define _SUBSCRIPTIONSTYPE_H_

enum class SubscriptionType {Player, Hoard, Dragon, Enemy, Netural,Tile, Potion,Wall, Stair};// to be added

#endif
