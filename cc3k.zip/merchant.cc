#include "merchant.h"
//static field for Merchant, if isNeutral is false, it means merchant becomes enemy
bool Merchant::isNeutral = 1;

//constructor
Merchant::Merchant(){
    this->image = 'M';
}

//destructor
Merchant::~Merchant(){}


//returns the subscription type of enemy
SubscriptionType Merchant::subType() const {
    if(isNeutral) {
        return SubscriptionType::Netural;
    } else {
        return SubscriptionType::Enemy;
    }
}

// get attack from player
void Merchant::get_attack(Character *c){
    if(isValid) {
        return;
    }
    int damage = ceil((100/(100 + this->DEF))*(c->ATK));
    HP -= damage;
    isNeutral = 0;
    if (c->race == "Troll"){
        c->HP += 5;
        c->HP = c->HP > 120 ?  120 : c->HP;
    } else if(c->race == "Vampire") {
        c->HP += 5;
    }
    if (HP <= 0) {
        this->image = '.';
        isValid = 1;
        isFrozen = 1;
    }
}
