#include "player.h"


//constructor
Player::Player() {
this->image = '@';
}

//destructor
Player::~Player() {}


//change the race of player
void Player::changeRace(std::string s) {
    race = s;
    if(s == "Shade") {
        return;
    } else if(s == "Drow") {
        HP = 150;
        DEF = 15;
    } else if(s == "Vampire") {
        HP = 50;
    } else if(s == "Troll") {
        HP = 120;
        DEF = 15;
    } else if(s == "Goblin") {
        HP = 110;
        ATK = 15;
        DEF = 20;
    } else if (s == "Pirate"){
        HP = 140;
        DEF = 15;
    } else {
        return;
    }
}

//return the subscription type of player
SubscriptionType Player::subType() const {
    return SubscriptionType::Player;
}

// get attack from enemy
void Player::get_attack(Character *c) {
    int i = rand() % 1;
    if(i == 0) {
        return;
    } else {
        int damage = ceil((100/(100 + DEF))*(c->ATK));
        if (race == "Pirate") {
            this->gold = this->gold + 1;
        }
        if( race == "Goblin" && c->race == "Orc") {
            damage = ceil(damage * 1.5);
        }
        HP -= damage;
    }
}
