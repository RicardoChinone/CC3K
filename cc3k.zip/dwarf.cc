#include "dwarf.h"

using namespace::std;

//constructor
Dwarf::Dwarf(){
    this->image = 'W';
   // this->dir = rand() % 4 + 1;
}

//destructor
Dwarf::~Dwarf() {}


//returns the subscription type of enemy
SubscriptionType Dwarf::subType() const {
    if(isValid){
        return SubscriptionType::Tile;
    } else {
        return SubscriptionType::Enemy;
    }
}

// get attack from player
void Dwarf::get_attack(Character *c){
    if(isValid) {
        return;
    }
    int damage = ceil((100/(100 + this->DEF))*(c->ATK));
    HP -= damage;
    if (c->race == "Troll"){
        c->HP += 5;
        c->HP = c->HP > 120 ?  120 : c->HP;
    } else if(c->race == "Vampire") {
        c->HP -= 5;
    }
    if (HP <= 0) {
        this->image = '.';
        isValid = 1;
        isFrozen = 1;
    }
}

