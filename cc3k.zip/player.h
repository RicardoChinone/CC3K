#ifndef __PLAYER_H_
#define __PLAYER_H_

#include "character.h"

struct Player :public Character {
    std::string race = "Shade";
    int HP = 125;
    int ATK = 25;
    int DEF = 25;
    int gold = 0;
    Player();
    ~Player();
    void changeRace(std::string s);
    SubscriptionType subType() const override;
    void get_attack(Character *c) override;
};

#endif
